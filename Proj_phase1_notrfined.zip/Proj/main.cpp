#include <iostream>
#include <vector>
#include <cstring>
#include <fstream>
#include <ctime>
using namespace std;
vector<string> s1;
class location{
    public:
    string name;
    string sector;
    int isbin;
    int pfull;
    location(){
        name = "";
        sector = "";
        isbin = 0;
        pfull = -1;
    }
    location(string n,string s,int b,int al){
        name = n;
        sector = s;
        isbin = b;
        pfull = al;
    }
    location(const location& l1){
        name = l1.name;
        sector = l1.sector;
        isbin = l1.isbin;
        pfull = l1.pfull;
    }
    void setname(string n){
        name = n;
    }
    void setsector(string s){
        sector = s;
    }
    void setisbin(int x){
        isbin = x;
    }
    void setpfull(int x){
        pfull = x;
    }
    void print(){
        cout<<"Street Name: "<<name<<endl;
        cout<<"Secotor: "<<sector<<endl;
        cout<<"Percent Full: "<<pfull<<endl;
        if(isbin == 0){
            cout<<"Its a Bin"<<endl;
        }else if(isbin == 1){
            cout<<"Its a Departure point"<<endl;
        }else if(isbin == 2){
            cout<<"Its a Dumping point"<<endl;
        }
    }
    bool operator==(const location& l1){
        if(name == name){
            return true;
        }else
            return false;
    }
};
    ostream & operator<< (ostream &out, location &l){
        l.print();
        return out;
    }
class pairs{
    public:
    location first;
    int second;
    pairs(){
        second = -1;
    }
    pairs(location s1,int n){
        first = s1;
        second = n;
    }
    pairs(const pairs& p1){
        first = p1.first;
        second = p1.second;
    }
    void print(){
        cout<<"First : "<<first<<endl;
        cout<<"Second : "<<second<<endl;
    }
    bool operator ==(const pairs& p1){
        if(first == p1.first && second == p1.second){
            return true;
        }else{
            return false;
        }
    } 
};
    ostream & operator<< (ostream &out, pairs &p){
        p.print();
        return out;
    }

class pairstring{
    public:
    string first;
    int second;
    pairstring(){
        second = -1;
    }
    pairstring(string s1,int n){
        first = s1;
        second = n;
    }
    pairstring(const pairstring& p1){
        first = p1.first;
        second = p1.second;
    }
    void print(){
        cout<<"First : "<<first<<endl;
        cout<<"Second : "<<second<<endl;
    }
    bool operator ==(const pairstring& p1){
        if((first == p1.first) && (second == p1.second)){
            return true;
        }else{
            return false;
        }
    } 
};
    ostream & operator<< (ostream &out, pairstring &p){
        p.print();
        return out;
    }


class pairbool{
    public:
    string first;
    bool second;
    pairbool(){
        second = -1;
    }
    pairbool(string s1,bool n){
        first = s1;
        second = n;
    }
    pairbool(const pairbool& p1){
        first = p1.first;
        second = p1.second;
    }
    void print(){
        cout<<"First : "<<first<<endl;
        cout<<"Second : "<<second<<endl;
    }
    bool operator ==(const pairbool& p1){
        if((first == p1.first) && (second == p1.second)){
            return true;
        }else{
            return false;
        }
    } 
};
    ostream & operator<< (ostream &out, pairbool &p){
        p.print();
        return out;
    }
    

class MinHeap
{
    vector<pairstring> arr;
    int maxsize;
    int numelements;

public:
    MinHeap(int arrsize)
    {
        maxsize = arrsize;
        arr.resize(++arrsize);
        numelements = 0;
    }
    pairstring min()
    {
        return arr[1];
    }
    int size()
    {
        return numelements;
    }
    void Push(pairstring val)
    {
        if (numelements == maxsize)
        {
            cout << "Heap is full!" << endl;
            return;
        }
        int index = ++numelements;
        arr[index] = val;

        while (index > 1)
        {
            int parent = index / 2;

            if (arr[parent].second > arr[index].second)
            {
                swap(arr[parent], arr[index]);
                index = parent;
            }
            else
            {
                return;
            }
        }
    }
    void Pop()
    {
        if (numelements == 0)
        {
            cout << "Heap is empty!" << endl;
            return;
        }

        pairstring temp = arr[1];
        arr[1] = arr[numelements];
        numelements--;

        int i = 1;
        while (i < numelements)
        {
            int LC = 2 * i;
            int RC = (2 * i) + 1;
            int largest = i;

            if (LC <= numelements && arr[largest].second > arr[LC].second)
                largest = LC;

            if (RC <= numelements && arr[largest].second > arr[RC].second)
                largest = RC;

            if (largest == i)
            {
                break;
            }
            else
            {
                swap(arr[i], arr[largest]);
                i = largest;
            }
        }
    }
    void display()
    {
        for (int i = 0; i < numelements; i++)
        {
            cout << arr[i + 1] << " ";
        }
        cout << endl;
    }
    bool isempty(){
        return (numelements == 0);  
    }   
    bool findd(pairstring& p1){
        for (int i = 0; i <= numelements; i++)
        {
            if(p1.second == arr[i].second){
                return true;
            }
        }
        return false;
    }
};


class node{
    public:
    pairs data;
    node * next;
    node(pairs& x){
        data = x;
        next = NULL;
    }
};
class adjlist{
    public:
    node * head;
    node * tail;
    adjlist(){
        head = NULL;
        tail = NULL;
    }
    void insert(pairs& x){
        if(head==NULL){
            head = new node(x);
            tail = head;
            return;
        }else{
            tail->next = new node(x);
            tail = tail->next;
        }
        return;
    }
    void print(){
        if(head == NULL){
            cout<<"List empty"<<endl;
            return;
        }
        cout <<"Vertice : "<<head->data<<" , Neighbours: ";
        for (node * i = head->next; i != NULL; i = i->next)
        {
            cout<<i->data<<" ";
        }
        cout<<endl;
    }
    pairs paor(string name){
        pairs p1;
        for (node* i = head; i !=NULL; i=i->next)
        {
            if(i->data.first.name == name){
                p1 = i->data;
            }
        }
        return p1;
    }
};
class graph{
    public:
    vector<adjlist> arr;
    int vert;

    graph(){
    }
    void insert(vector<vector<pairs>>& v1){
        vert = v1.size();
        pairs p1;
        for (int i = 0; i < vert; i++)
        {
            arr.push_back(adjlist());
            for (int j = 0; j < v1[i].size(); j++)
            {
                arr[i].insert(v1[i][j]);
            }
            
        }
        
    }
    void showGraphStructure(){
        for (int i = 0; i < vert; i++)
        {
            arr[i].print();
            cout<<endl;
        }
    }
    vector<pairstring> dj_algo(string src){
        vector<pairstring> distances;
        for (int i = 0; i < arr.size(); i++)
        {
            distances.push_back(pairstring(arr[i].head->data.first.name,0));
            distances[i].second = 100;
        }
        MinHeap M1(100);
        int source;
        for (source = 0; source < distances.size(); source++)
        {
            if(distances[source].first == src){
                distances[source].second = 0;
                break;
            }
        }
        M1.Push(pairstring(distances[source].first,0));
        // cout<<"xd";

        while (!M1.isempty())
        {
            pairstring p1 = M1.min();
            int nodedist = p1.second;
            M1.Pop();
            int is = 0;
            for (; is < arr.size(); is++)
            {
                if(p1.first == arr[is].head->data.first.name){
                    break;
                }
            }
            for (node* i = arr[is].head->next; i!=NULL; i = i->next)
            {   int is = 0;
                for (; is < arr.size(); is++)
                {
                    if(i->data.first.name == arr[is].head->data.first.name){
                        break;
                    }
                }

                if((nodedist + i->data.second) < distances[is].second){
                    if(M1.findd(distances[is])){
                        // cout<<"xxxxxxxx";
                        // cout<<"ddddddd";
                        M1.Pop();
                    }
                    distances[is].second = nodedist + i->data.second;
                    M1.Push(distances[is]);
                }
            }
            
            

        }
      return distances;  
    } 
};
vector<graph> grap;

class truckdriver{
    string name;
    string username;
    string password;
    int sec;
    // Graph pew;    

    public:
        truckdriver(){
            name = "";
            username = "";
            password = "";
            sec = -1;
        }
        truckdriver(string name,string usrname,string pass,int sector){
            this->name  = name;
            username = usrname;
            password = pass;
            sec = sector;
        }
        void setname(string n){
            name = n;
        }
        void setusrname(string usr){
            username = usr;            
        }
        void setpass(string pass){
            password = pass;
        }
        void setsec(int x){
            sec = x;
        }
        string getname(){
            return name;
        }
        string getusrname(){
            return username;
        }
        string getpass(){
            return password;
        }
        int getsector(){
            return sec;
        }

        void print(){
            cout<<"Name: "<<name<<endl;
            cout<<"Username: "<<username<<endl;
            cout<<"Password: "<<password<<endl;
            cout<<"Sector val: "<<sec<<endl;
        }
};
class controller{
    string name;
    string username;
    string password;
    // Graph pew;    

    public:
        controller(){
            name = "";
            username = "";
            password = "";
        }
        controller(string name,string usrname,string pass){
            this->name  = name;
            username = usrname;
            password = pass;
        }
        void setname(string n){
            name = n;
        }
        void setusrname(string usr){
            username = usr;            
        }
        void setpass(string pass){
            password = pass;
        }
        string getname(){
            return name;
        }
        string getusrname(){
            return username;
        }
        string getpass(){
            return password;
        }
        void print(){
            cout<<"Name: "<<name<<endl;
            cout<<"Username: "<<username<<endl;
            cout<<"Password: "<<password<<endl;
        }
};
void displaybins(){
    int counter = 1;
    for (int i = 0; i < grap.size(); i++)
    {
        for (int j = 0; j < grap[i].arr.size()-2; j++)
        {
            cout<<counter++<<" - "<<grap[i].arr[j].head->data.first.name<<" - "<<grap[i].arr[j].head->data.first.pfull<<endl;
        }
    }
    
}
void swappair(pairstring & p1 ,pairstring & p2){
    pairstring p3;
    p3 = p1;
    p1 = p2;
    p2 = p3;
}
void bubbleSort(vector<pairstring> arr, int n)
{
    int i, j;
    bool swapped;
    for (i = 0; i < n - 1; i++) {
        swapped = false;
        for (j = 0; j < n - i - 1; j++) {
            if (arr[j].second > arr[j + 1].second) {
                swappair(arr[j], arr[j + 1]);
                swapped = true;
            }
        }
 
        // If no two elements were swapped
        // by inner loop, then break
        if (swapped == false)
            break;
    }
}

void checkbin(graph& g1,int x,string na){
    vector<location> v1;
    vector<int> index;
    for (int i = 0; i < g1.vert; i++)
    {
        if(g1.arr[i].head->data.first.pfull >= x){
            v1.push_back(g1.arr[i].head->data.first);
            index.push_back(i);
        }
    }
    v1.push_back(g1.arr[10].head->data.first);
    index.push_back(10);
    v1.push_back(g1.arr[11].head->data.first);
    index.push_back(11);
    // for (int i = 0; i < v1.size(); i++)
    // {
    //     cout<<v1[i];
    // }
    
    vector<vector<pairs>> pai;
    vector<pairs> pp;
    pairs temp;
    cout<<endl<<endl;
    for (int i = 0; i < v1.size(); i++)
    {
        pp.push_back(pairs(v1[i],-1));
        for (int j = 0; j < v1.size(); j++)
        {
            if(i==j)
                continue;
            temp = g1.arr[index[i]].paor(v1[j].name);
            // cout<<"x";
            pp.push_back(temp);
        }
        pai.push_back(pp);
        pp.clear();
    }
    // for (int i = 0; i <pai.size(); i++)
    // {
    //     for(int j=0;j<pai[i].size();j++){
    //         cout<<pai[i][j];
    //     }cout<<"next"<<endl;
    // }
    graph g2;
    g2.insert(pai);
    // g2.showGraphStructure();
    string chkname = na;
    chkname.append(" Departure");
    string chkout = na;
    chkout.append(" Dumping");

    string add;
    add = chkname;
    vector<pairstring> f1= g2.dj_algo(chkname);

    bubbleSort(f1,f1.size());
    add.append(" -> ");
    for (int i = 1; i < f1.size(); i++)
    {
        if(f1[i].first == chkname || f1[i].first == chkout){
            continue;
        }
        add.append(f1[i].first);
        add.append(" -> ");
    }
    add.append(chkout);
    // g2.showGraphStructure();
    s1.push_back(add);

}
void fun(vector<truckdriver> & v1,int idx){        
    cout<<"***Welcome Mr."<<v1[idx].getname()<<"***"<<endl;
    int x = v1[idx].getsector();
    cout<<s1[x]<<endl;
}
void fun2(vector<controller> & v1,int idx){        //umer Controller ka asli kaam
    int cond;
    int thesh = 0;
    do
    {
        cout<<"***Welcome to Controller "<<v1[idx].getname()<<"***"<<endl;
        cout<<"1 - View Bin Data of All Areas"<<endl;
        cout<<"2 - Set ThreshHold and Send Notifications"<<endl;
        cout<<"3 - Exit"<<endl;
        cout<<"Enter Choice : ";
        cin>>cond;
        if(cond == 1){
            displaybins();
        }else if (cond == 2)
        {
            cout<<"Enter the Value of ThreshHold: ";
            cin>>thesh;
            checkbin(grap[0],thesh,"F-6");
            checkbin(grap[1],thesh,"F-7");
            checkbin(grap[2],thesh,"F-8");
            checkbin(grap[3],thesh,"F-10");
            checkbin(grap[4],thesh,"F-11");
            cout<<"ThreshHold is setted, And Notification have been sent to TruckDrivers"<<endl;
        }else if (cond == 3)
        {
            break;
        }else{
            cout<<"Invalid Input, Enter Again : ";
            cin>>cond;
        }
        
    } while (cond != 3);
}

void logintruck(vector<truckdriver> & v1){
    cout<<endl<<endl;
    cout<<"***TruckDriver Login Portal***"<<endl;
    string x;
    string y;
    cout<<"Enter The username : ";
    cin.ignore();
    getline(cin,x);
    cout<<"Enter the Password : ";
    getline(cin,y);
    int i=0;
    for (i = 0; i < v1.size(); i++)
    {
        if(x == v1[i].getusrname()){
            if(y == v1[i].getpass()){
                break;       
            }
        }
    }
    if(i == v1.size()){
        cout<<"Login Failed!"<<endl;
    }else{
        cout<<"Logined Successfully"<<endl;
        fun(v1,i);
    }
}
void registertruck(vector<truckdriver> & v1)
{
    cout<<endl<<endl;
    cout<<"***TruckDriver Register Portal***"<<endl;
    string x;
    string y;
    string z;
    cout<<"Enter The Name for new user : ";
    cin.ignore();
    getline(cin,x);
    cout<<"Enter the Username for new user : ";
    getline(cin,y);
    cout<<"Enter the Password for new user : ";
    getline(cin,z);

    truckdriver t1(x,y,z,-1);
    v1.push_back(t1);
    ofstream out("truckdriver.csv");
    for (int i = 0; i < v1.size(); i++)
    {   if(i!=0)
            out<<endl;
        out<<v1[i].getname()<<","<<v1[i].getusrname()<<","<<v1[i].getpass();
    }
    out.close();
}
void logincontrol(vector<controller> & v1){
    cout<<endl<<endl;
    cout<<"***Controller Login Portal***"<<endl;
    string x;
    string y;
    cout<<"Enter The username : ";
    cin.ignore();
    getline(cin,x);
    cout<<"Enter the Password : ";
    getline(cin,y);
    int i=0;
    for (i = 0; i < v1.size(); i++)
    {
        if(x == v1[i].getusrname()){
            if(y == v1[i].getpass()){
                break;       
            }
        }
    }
    if(i == v1.size()){
        cout<<"Login Failed!"<<endl;
    }else{
        cout<<"Logined Successfully"<<endl;
        fun2(v1,i);
    }
}
void registercontrol(vector<controller> & v1){
    cout<<endl<<endl;
    cout<<"***Controller Register Portal***"<<endl;
    string x;
    string y;
    string z;
    cout<<"Enter The Name for new Controller : ";
    cin.ignore();
    getline(cin,x);
    cout<<"Enter the Username for new Controller : ";
    getline(cin,y);
    cout<<"Enter the Password for new Controller : ";
    getline(cin,z);

    controller t1(x,y,z);
    v1.push_back(t1);
    ofstream out("controller.csv");
    for (int i = 0; i < v1.size(); i++)
    {   if(i!=0)
            out<<endl;
        out<<v1[i].getname()<<","<<v1[i].getusrname()<<","<<v1[i].getpass();
    }
    out.close();
}
void truck(){
    ifstream fin("truckdriver.csv");
    truckdriver t1;
    string c;
    int cond = -1;
    int i=0;
    vector<truckdriver> v1;
    while (!fin.eof())
    {
        getline(fin, c,',');
        t1.setname(c);
        getline(fin, c,',');
        t1.setusrname(c);
        getline(fin, c);
        t1.setpass(c);
        t1.setsec(i++);
        v1.push_back(t1);
        // fin.ignore();
    }

    fin.close();
    system("clear");
    do
    {
        cout<<"***Truck Driver Dashboard***"<<endl;
        cout<<"1 - Login"<<endl;
        cout<<"2 - Register"<<endl;
        cout<<"3 - Exit"<<endl;
        cout<<"Enter Choice : ";
        cin>>cond;
        if(cond == 1){
            logintruck(v1);
        }else if (cond == 2)
        {
            registertruck(v1);
        }else if (cond == 3)
        {
            break;
        }else{
            cout<<"Invalid Input, Enter Again : ";
            cin>>cond;
        }
        
    } while (cond != 3);
    // for (int i = 0; i < v1.size(); i++)
    // {
    //     v1[i].print();
    // }
}
void control(){
    ifstream fin("controller.csv");
    controller t1;
    string c;
    int cond = -1;
    vector<controller> v1;
    while (!fin.eof())
    {
        getline(fin, c,',');
        t1.setname(c);
        getline(fin, c,',');
        t1.setusrname(c);
        getline(fin, c);
        t1.setpass(c);
        v1.push_back(t1);
        // fin.ignore();
    }

    fin.close();
    system("clear");
    do
    {
        cout<<"***Controller Dashboard***"<<endl;
        cout<<"1 - Login"<<endl;
        cout<<"2 - Register"<<endl;
        cout<<"3 - Exit"<<endl;
        cout<<"Enter Choice : ";
        cin>>cond;
        if(cond == 1){
            logincontrol(v1);
        }else if (cond == 2)
        {
            registercontrol(v1);
        }else if (cond == 3)
        {
            break;
        }else{
            cout<<"Invalid Input, Enter Again : ";
            cin>>cond;
        }
        
    } while (cond != 3);
    // for (int i = 0; i < v1.size(); i++)
    // {
    //     v1[i].print();
    // }
    

}
void menu(){
    int cond = -1;
    do
    {   cout<<"***Welcome to Waste Managemnet Dashboard***"<<endl<<endl;
        cout<<"1 - TruckDriver"<<endl;
        cout<<"2 - Bus Controller"<<endl;
        cout<<"3 - Exit"<<endl;
        cin>>cond;
        if(cond == 1){
            truck();
        }else if (cond == 2)
        {
            control();
        }else if(cond == 3){
            break;
        }else{
            cout<<"Invalid Input, Enter Again : ";
            cin>>cond;
        }
    } while (cond!=3);
    
}
void read_locations(vector<vector<vector<pairs>>>& vv1){
    ifstream fin("FSector.csv");
    ifstream fil("Binfill.txt");
    vector<vector<pairs>> v1;
    for(int ppp=0;ppp<5;ppp++){
        vector<int>dat;
        int lim = rand()%72;
        // cout<<lim<<endl;
        for (int i = 0; i < 72; i++)
        {
            int pu;
            fil>>pu;
            fil.ignore();
            if(i == lim)
            {for (int j = 0; j < 50; j++)
            {
                int pu;
                fil>>pu;
                dat.push_back(pu);
                fil.ignore();
            }
            break;}
            
        }
        // for (int i = 0; i < dat.size(); i++)
        // {
        //     cout<<dat[i]<<" ";
        // }cout<<endl;
        
        vector<pairs> tem;
        pairs p1;
        int count = 0;
        string x;
        int l;
        location temp;
        for (int i = 0; i < 12; i++)
        {   
            for (int j = 0; j < 12; j++)
            {
                getline(fin,x,',');
                temp.setname(x);
                fin>>l;
                fin.ignore();
                if(ppp == 0)
                    temp.setsector("F-6");
                if(ppp == 1)
                    temp.setsector("F-7");
                if(ppp == 2)
                    temp.setsector("F-8");
                if(ppp == 3)
                    temp.setsector("F-10");
                if(ppp == 4)
                    temp.setsector("F-11");
                if(x[0] == 'S')
                    temp.setisbin(0);
                else if(x[5] == 'e')
                    temp.setisbin(1);
                else{
                    temp.setisbin(2);
                }
                p1.first = temp;
                p1.second = l;
                
                tem.push_back(p1);
            }
            fin.ignore();
            if(i<10)
                tem[0].first.pfull = dat[count++];
            v1.push_back(tem);
            tem.clear();
        }
        vv1.push_back(v1);
        v1.clear();
        dat.clear();
        count = 0;
    }
    fin.close();
    fil.close();
}
int main(){
    srand(time(0));
    // ofstream out("truckdriver.csv");
    // truckdriver t1("Umer","umer@123","12345678");
    // truckdriver t2("Bilal","bilal@456","87654321");
    // truckdriver t3("Saif","saif@789","123456789");
    // truckdriver t4("Humayun","humayun@321","987654321");
    // truckdriver t5("Arsalan","arsalan@654","123456");

    // vector<truckdriver> vec;
    // vec.push_back(t1);
    // vec.push_back(t2);
    // vec.push_back(t3);
    // vec.push_back(t4);
    // vec.push_back(t5);
    // for (int i = 0; i < vec.size(); i++)
    // {
    //     out<<vec[i].getname()<<","<<vec[i].getusrname()<<","<<vec[i].getpass()<<endl;
    // }
    vector<vector< vector<pairs> > > v1;
    read_locations(v1);
    for (int i = 0; i < 5; i++)
    {
        grap.push_back(graph());
        grap[i].insert(v1[i]);
    }
    // for (int i = 0; i < grap.size(); i++)
    // {
        // grap[i].showGraphStructure();
    // }

    menu();
    
    
    // for (int i = 0; i < v1.size(); i++)
    // {
    //     for (int j = 0; j < v1[i].size(); j++)
    //     {
    //         cout<<v1[i][j]<<" ";
    //     }
    //     cout<<endl;
    // }
    // checkbinF6(g1,75);

    // g1.showGraphStructure();
    // for (int i = 0; i < s1.size(); i++)
    // {
    //     cout<<s1[i]<<endl;
    // }
    
    
    return 0;
}