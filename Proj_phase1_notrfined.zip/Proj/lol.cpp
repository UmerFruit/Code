#include <iostream>
#include <vector>
using namespace std;

int main(){

    int a;
    int b;
    cin>>a;
    cin.ignore();
    cin>>b;

    cout<<a<<" "<<b;


}